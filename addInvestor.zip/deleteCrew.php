<?php
	$id = $_GET['idd'];
	include('DB.php');
	echo $id;
	$deleteSQL ="DELETE FROM staff WHERE StaffNo = '$id'";
	$deleteQuery = mysqli_query($con, $deleteSQL);

	header("location:accountadmin.php");
?>