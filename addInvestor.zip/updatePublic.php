<?php
	include("DB.php");
	$no = $_GET['pNo'];
	$name = $_GET['pName'];
	$DOB = $_GET['pDOB'];

	$updatePublicsql = "UPDATE public SET PublicName = '$name', DOB='$DOB' WHERE PublicNo='$no'";
	mysqli_query($con, $updatePublicsql);
	echo $updatePublicsql;
	header("location:accountadmin.php");
?>