<?php
//connect to database
	include 'extras/connect.php';
	//retrieve all available jobs
			$result = mysqli_query($mysqli,"SELECT ProductionNo, ProductionName, OverviewURL, StartDate from production where Complete = 'N'");
			while($row = mysqli_fetch_assoc($result)){
				//print out details for each job
				echo"<tr>
						<td>".$row['ProductionNo']."</a></td>
						<td>".$row['ProductionName']."</a></td>
						<td>".$row['StartDate']."</td>
						<td><a href='".$row['OverviewURL']."' download> Read Overview </a></td>
						</tr>";
			}
			//close database connection
			$mysqli->close();
		
?>