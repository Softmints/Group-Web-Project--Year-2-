<?php
	include("DB.php");
	$id= $_GET['id'];
	$production = $_GET['production'];


	$sqlProduction = "SELECT ProductionNo FROM production WHERE ProductionName = '$production'";
	$query = mysqli_query($con, $sqlProduction);
	$fetch = mysqli_fetch_row($query);
	$productionID = $fetch[0];

	$sql="DELETE FROM investedProduction WHERE InvestorNo='$id' AND ProductionNo='$productionID'"; 
	mysqli_query($con,$sql);

	header("location:accountadmin.php");
?>