
<?php
	include("DB.php");
	$getID="SELECT MAX(InvestorNo) FROM investor";
	$getIDresult = mysqli_query($con, $getID);
	$maxID = mysqli_fetch_row($getIDresult);
	$maxIDvalue= $maxID[0];
	$newID = $maxIDvalue + 1;

	$no = $_GET['iNo'];
	$name = $_GET['iName'];
	$lastName = $_GET['iLastName'];

	$addInvestorsql = "INSERT INTO investor Values ('$newID',  '$name','$lastName')";
	mysqli_query($con, $addInvestorsql);
	echo $addInvestorsql;
	header("location:accountadmin.php");



?>