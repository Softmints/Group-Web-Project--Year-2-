
<html>
<head>
	<script src= "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</head>
<body>
	<script >
			$(document).on("click", ".updateStaff", function(){ 
					var myPublicId = $(this).data('id');
					var staffData = myPublicId.split(" ");
					$("#txtStaffNo").val(staffData[0]);
					$("#txtStaffName").val(staffData[1]);
					$("#txtStaffJob").val(staffData[2]);
				})		

				$(document).on("click", "#btnStaffUpdate", function(){
					
			   		var sName = document.getElementById('txtStaffName').value;
			   		var sNo = document.getElementById('txtStaffNo').value;
			   		var sJob = document.getElementById('txtStaffJob').value;
			   		var errors = 0;
			   		if (sName=="" || sNo =="" ||sJob==""){
			   			alert("Please Complete all fields");
			   			errors= 1;
			   		} else {
			   			errors = 0;
			   		}
			   		if (errors ==0){
						window.location.href = "updateStaff.php?sNo=" + sNo + "&sName="+ sName + "&sJob=" + sJob;
			   		}
			   		
			   		
			   		})	
			   		$(document).on("click", ".btnStaffAdd", function(){
			   			var errors=0;
			   		var staffName = document.getElementById('txtAddStaffName').value;
			   		var staffNo = document.getElementById('txtAddStaffNo').value;
			   		var staffJob = document.getElementById('txtAddStaffJob').value;
			   		if (staffName=="" || staffNo =="" ||staffJob==""){
			   			alert("Please Complete all fields");
			   			errors= 1;
			   		} else {
			   			errors = 0;
			   		}
			   		if (errors ==0){
						window.location.href = "addStaff.php?sNo=" + staffNo + "&sName="+ staffName + "&sJob=" + staffJob;
			   		}
			   		})																										  	
		  </script>

<?php 
			$selectStaff = "SELECT * FROM staff";
			$selectStaffQuery = mysqli_query($con, $selectStaff);

			while ($selectStaffList = mysqli_fetch_assoc($selectStaffQuery)) {
			?> <tr> <?php
			$StaffNo = $selectStaffList['StaffNo'];
			$StaffName = $selectStaffList['StaffName'];
			$StaffJob = $selectStaffList['JobTitle'];
			?> <td> <?php echo $StaffNo; ?> </td> <?php
			?> <td> <?php echo $StaffName; ?> </td> <?php
			?> <td> <?php echo $StaffJob; ?> </td> <?php
			?><td><a href="#" class="updateStaff" data-id = "<?php echo $StaffNo . " " . $StaffName . " " . $StaffJob ?>" data-reveal-id="crew">Update</a>|
			<a href="deleteCrew.php?idd=<?php echo $StaffNo ?>">Delete</a></td> <?php
			?> </tr> <?php
	}
?>


</body>
</html>