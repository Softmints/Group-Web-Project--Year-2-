<?php
	include("DB.php");
	$getID="SELECT MAX(PublicNo) FROM public";
	$getIDresult = mysqli_query($con, $getID);
	$maxID = mysqli_fetch_row($getIDresult);
	$maxIDvalue= $maxID[0];
	$newID = $maxIDvalue + 1;

	$no = $_GET['pNo'];
	$name = $_GET['pName'];
	$DOB = $_GET['pDOB'];

	$addPublicsql = "INSERT INTO public Values ('$newID',  '$name','$DOB')";
	mysqli_query($con, $addPublicsql);
	header("location:accountadmin.php");



?>