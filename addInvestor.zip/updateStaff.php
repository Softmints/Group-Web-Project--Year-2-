<?php
	include("DB.php");
	$no = $_GET['sNo'];
	$name = $_GET['sName'];
	$Job = $_GET['sJob'];

	$updateStaffsql = "UPDATE staff SET StaffName = '$name', JobTitle='$Job' WHERE StaffNo='$no'";
	mysqli_query($con, $updateStaffsql);
	echo $updateStaffsql;
	header("location:accountadmin.php");
?>