
<?php
echo "<video width='320' height='240' controls>
  <source src='".$_GET['location']."' type='".$_GET['type']."'>
	</video>";
?>