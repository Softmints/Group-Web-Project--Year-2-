<?php

	include 'extras/connect.php';
/*
	The variables below collect the information submitted by the Login.php page and assign them to variables.
	The $EncryptPass variable changes the $Password variable to have md5 encryption. This is needed as md5
	encryption is applied by the registeration proccess. For the SQL query to correctly select the row the
	passwords need to match exactly so the encryption has to be applied during the login proccess also.
*/

	$Username = $_POST['Username'];
	$Password = $_POST['Password'];
	$EncryptPass = md5($Password);

	$query = "SELECT * FROM logininfo WHERE username='$Username' AND password='$EncryptPass'";
	$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
	$Check = mysqli_num_rows($result);
	$row = $result->fetch_array(MYSQLI_NUM);
	$privelege = $row[3];
	$userID = $row[4];

	if($Check == 1 && $privelege == 'public') {

		$query = "SELECT * FROM public WHERE PublicNo='$userID'";
		$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
		$Check2 = mysqli_num_rows($result);
		$row = $result->fetch_array(MYSQLI_NUM);
		$userName = $row[1];

			if($Check2 == 1) {
			
			setcookie('usergroup','public', time()+3600, '/');
			setcookie('userID', $userID, time()+3600, '/');
			setcookie('userName', $userName, time()+3600, '/');
			header("location:public.php");

		}
		
	}

		else if($Check == 1 && $privelege == 'staff') {

			$query = "SELECT * FROM staff WHERE StaffNo='$userID'";
			$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
			$Check3 = mysqli_num_rows($result);
			$row = $result->fetch_array(MYSQLI_NUM);
			$userName = $row[1];

				if($Check3 == 1) {
				
				setcookie('usergroup','staff', time()+3600, '/');
				setcookie('userID', $userID, time()+3600, '/');
				setcookie('userName', $userName, time()+3600, '/');
				echo $_COOKIE['userName'];
				echo $userName;
				header("location:staff.php");
			}
				

		}

			else if($Check == 1 && $privelege == 'investor'){

				$query = "SELECT * FROM investor WHERE InvestorNo='$userID'";
				$result = $mysqli->query($query) or die($mysqli->error.__LINE__);
				$Check4 = mysqli_num_rows($result);
				$row = $result->fetch_array(MYSQLI_NUM);
				$userName = $row[1];

					if($Check4 == 1) {
					
					setcookie('usergroup','investor', time()+3600, '/');
					setcookie('userID', $userID, time()+3600, '/');
					setcookie('userName', $userName, time()+3600, '/');
					header("location:investors.php");
				}

			}

				else if($Check == 1 && $privelege == 'admin'){

					
					setcookie('usergroup','admin', time()+3600, '/');
					setcookie('userID', $userID, time()+3600, '/');
					setcookie('userName', $userName, time()+3600, '/');
					header("location:accountadmin.php");
				}


	else {
		echo '<script language="javascript">'; 
		echo 'alert("Login Failed!" );'; 
		echo ' window.location="registeredusers.html";'; 
		echo '</script>'; 
	}
?>