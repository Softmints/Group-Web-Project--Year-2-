<?php
	include 'connection.php';
	
			//Print the reulst as a list
			    //Print the reulst as a list
			$result = mysqli_query($conn,"SELECT MediaNo, MediaName, MediaURL, UDate from media WHERE Catagory ='$Catagory'");
			while($row = mysqli_fetch_assoc($result)){
				echo"<tr>
						<td><a href=".$row['MediaURL'].">".$row['MediaName']."</a></td>
						<td>".$row['UDate']."</td>
						</tr>";
			}
			
			 	
			
		
			//close database connection
			$conn->close();
		
?>