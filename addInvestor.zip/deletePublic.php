<?php
	$id = $_GET['idd'];
	include('DB.php');
	echo $id;
	$deleteSQL ="DELETE FROM public WHERE publicNo = '$id'";
	$deleteQuery = mysqli_query($con, $deleteSQL);

	header("location:accountadmin.php");
?>