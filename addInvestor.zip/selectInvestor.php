

<html>
<head>
	<script src= "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</head>
<body>
	<script >
			$(document).on("click", ".updateInvestor", function(){ 
					var myPublicId = $(this).data('id');
					var investorData = myPublicId.split(" ");

					$("#txtInvestorNo").val(investorData[0]);
					$("#txtInvestorFirstName").val(investorData[1]);
					$("#txtInvestorLastName").val(investorData[2]);
				})	

				$(document).on("click", ".btnInvestorUpdate", function(){
			   		var iName = document.getElementById('txtInvestorFirstName').value;
			   		var iNo = document.getElementById('txtInvestorNo').value;
			   		var iLastName = document.getElementById('txtInvestorLastName').value;
			   		
			   		var errors = 0;
			   		if (iName=="" || iNo =="" ||iJob==""){
			   			alert("Please Complete all fields");
			   			errors= 1;
			   		} else {
			   			errors = 0;
			   		}
			   		if (errors ==0){
						window.location.href = "updateInvestor.php?iNo=" + iNo + "&iName="+iName + "&iLastName=" + iLastName;
			   		}
			   	})	

			   	$(document).on("click", ".btnAddInvestor", function(){
			   		
			   		alert(document.getElementById('txtAddInvestorFirstName').value);
			   		var investorAddName = document.getElementById('txtAddInvestorFirstName').value;
			   		var investorAddNo = document.getElementById('txtAddInvestorNo').value;
			   		var investorAddLastName = document.getElementById('txtAddInvestorLastName').value;
			   		
			   		var errors = 0;
			   		if (investorAddName=="" || investorAddNo =="" ||investorAddLastName==""){
			   			alert("Please Complete all fields");
			   			errors= 1;
			   		} else {
			   			errors = 0;
			   		}
			   		if (errors ==0){
						window.location.href = "addInvestor.php?iNo=" + investorAddNo + "&iName="+ investorAddName + "&iLastName=" + investorAddLastName;
			   		}
			   		})																											  	
		  </script>


<?php 
	$selectInvestor = "SELECT * FROM investor";
	$selectInvestorQuery = mysqli_query($con, $selectInvestor);

	while ($selectInvestorList = mysqli_fetch_assoc($selectInvestorQuery)) {
	?> <tr> <?php
	$InvestorNo = $selectInvestorList['InvestorNo'];
	$InvestorName = $selectInvestorList['InvestorFirstName'];
	$InvestorSurname = $selectInvestorList['InvestorLastName'];
	?> <td> <?php echo $InvestorNo; ?> </td> <?php
	?> <td> <?php echo $InvestorName; ?> </td> <?php
	?> <td> <?php echo $InvestorSurname; ?> </td> <?php
	?><td><a href="#"  data-id="<?php echo $InvestorNo . " " . $InvestorName . " " . $InvestorSurname?>" data-reveal-id="investors" class= "updateInvestor">Update</a>|
	<a href="deleteInvestor.php?idd=<?php echo $InvestorNo ?>">Delete</a></td> <?php
	?> </tr> <?php
	}
?>

</body>
</html>