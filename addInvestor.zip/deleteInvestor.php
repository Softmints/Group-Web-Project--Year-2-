<?php
	$id = $_GET['idd'];
	include('DB.php');
	
	$deleteSQL ="DELETE FROM investor WHERE InvestorNo = '$id'"; //MUST HAVE CASCADE TURNED ON
	$deleteQuery = mysqli_query($con, $deleteSQL);
	
	header("location:accountadmin.php");
?>