<?php
	include("DB.php");
	$getID="SELECT MAX(StaffNo) FROM staff";
	$getIDresult = mysqli_query($con, $getID);
	$maxID = mysqli_fetch_row($getIDresult);
	$maxIDvalue= $maxID[0];
	$newID = $maxIDvalue + 1;

	$no = $_GET['sNo'];
	$name = $_GET['sName'];
	$job = $_GET['sJob'];
	$addStaffsql = "INSERT INTO staff Values ('$newID',  '$name','$job')";
	mysqli_query($con, $addStaffsql);
	header("location:accountadmin.php");



?>